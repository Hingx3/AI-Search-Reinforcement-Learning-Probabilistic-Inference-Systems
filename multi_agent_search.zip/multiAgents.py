# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState


class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [
            index for index in range(len(scores)) if scores[index] == bestScore
        ]
        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        capsules = currentGameState.getCapsules()
        score = successorGameState.getScore()

        # Discourage STOP
        if action == Directions.STOP:
            score -= 10

        # Food
        foodList = newFood.asList()
        if foodList:
            minFoodDistance = min(manhattanDistance(newPos, food) for food in foodList)
            score += 10.0 / (minFoodDistance + 1)

        # Capsule
        if capsules:
            minCapsuleDist = min(manhattanDistance(newPos, cap) for cap in capsules)
            closestGhostDist = min(manhattanDistance(newPos, g.getPosition()) for g in newGhostStates)

            if closestGhostDist > 5 and minCapsuleDist <= 2:
                score += 8.0 / (minCapsuleDist + 1)  # mild reward to eat capsule
                if newPos in capsules:
                    score += 30  # extra if we actually eat it
            else:
                # discourage touching capsule when ghosts are near
                if newPos in capsules:
                    score -= 20

        # Ghost
        for i, ghost in enumerate(newGhostStates):
            ghostPos = ghost.getPosition()
            ghostDistance = manhattanDistance(newPos, ghostPos)

            if newScaredTimes[i] == 0:
                if ghostDistance < 2:
                    score -= 30
                elif ghostDistance < 5:
                    score += 0.2 * ghostDistance
            else:
                # Ghost is scared, eat it
                score += 5.0 / (ghostDistance + 1)

        successorGameState.data.score = score
        
        return successorGameState.getScore()


def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn="scoreEvaluationFunction", depth="2"):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)


class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        numAgents = gameState.getNumAgents()

        def minimax(state, agentIndex, depth):
            # Terminal
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)

            # Legal actions for the current agent
            actions = state.getLegalActions(agentIndex)
            if not actions:
                return self.evaluationFunction(state)

            # Determine next agent and update depth
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth

            # Pacman's turn
            if agentIndex == 0:
                bestScore = float("-inf")
                for action in actions:
                    successor = state.generateSuccessor(agentIndex, action)
                    score = minimax(successor, nextAgent, nextDepth)
                    bestScore = max(bestScore, score)
                return bestScore

            # Ghosts' turn
            else:
                bestScore = float("inf")
                for action in actions:
                    successor = state.generateSuccessor(agentIndex, action)
                    score = minimax(successor, nextAgent, nextDepth)
                    bestScore = min(bestScore, score)
                return bestScore

        # Pacman chooses the best action
        bestAction = None
        bestScore = float("-inf")
        for action in gameState.getLegalActions(0):
            successor = gameState.generateSuccessor(0, action)
            score = minimax(successor, 1, 0)
            if score > bestScore:
                bestScore = score
                bestAction = action

        return bestAction


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        numAgents = gameState.getNumAgents()

        def alphaBetaSearch(state, depth, agentIndex, alpha, beta):
            # Terminal
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)

            # Legal actions for the current agent
            legalActions = state.getLegalActions(agentIndex)
            if not legalActions:
                return self.evaluationFunction(state)

            # Determine next agent and update depth
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth

            # Pacman's turn
            if agentIndex == 0:
                maxScore = float("-inf")
                for action in legalActions:
                    nextState = state.generateSuccessor(agentIndex, action)
                    score = alphaBetaSearch(nextState, nextDepth, nextAgent, alpha, beta)
                    maxScore = max(maxScore, score)

                    # If current maxScore exceeds beta, stop exploring
                    if maxScore > beta:
                        return maxScore

                    # Update alpha
                    alpha = max(alpha, maxScore)
                return maxScore

            # Ghosts' turn
            else:
                minScore = float("inf")
                for action in legalActions:
                    nextState = state.generateSuccessor(agentIndex, action)
                    score = alphaBetaSearch(nextState, nextDepth, nextAgent, alpha, beta)
                    minScore = min(minScore, score)

                    # If current minScore is less than alpha, stop exploring
                    if minScore < alpha:
                        return minScore

                    # Update beta
                    beta = min(beta, minScore)
                return minScore

        # Pacman chooses the best action
        bestAction = None
        bestScore = float("-inf")
        alpha = float("-inf")
        beta = float("inf")

        for action in gameState.getLegalActions(0):
            nextState = gameState.generateSuccessor(0, action)
            score = alphaBetaSearch(nextState, 0, 1, alpha, beta)

            # Track the best action found so far
            if score > bestScore:
                bestScore = score
                bestAction = action

            # Update alpha
            alpha = max(alpha, bestScore)

        return bestAction


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
    Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        numAgents = gameState.getNumAgents()

        def expectimax(state, depth, agentIndex):
            # Terminal 
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)

            legalActions = state.getLegalActions(agentIndex)
            if not legalActions:
                return self.evaluationFunction(state)

            # Determine next agent and depth
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth

            # Pacman's turn
            if agentIndex == 0:
                bestScore = float("-inf")
                for action in legalActions:
                    nextState = state.generateSuccessor(agentIndex, action)
                    score = expectimax(nextState, nextDepth, nextAgent)
                    bestScore = max(bestScore, score)
                return bestScore

            # Ghosts' turn
            else:
                totalScore = 0
                for action in legalActions:
                    nextState = state.generateSuccessor(agentIndex, action)
                    score = expectimax(nextState, nextDepth, nextAgent)
                    totalScore += score
                averageScore = totalScore / len(legalActions)
                return averageScore

        # Choose the action with the highest expected score
        bestAction = None
        bestScore = float("-inf")

        for action in gameState.getLegalActions(0):
            successor = gameState.generateSuccessor(0, action)
            score = expectimax(successor, 0, 1)
            if score > bestScore:
                bestScore = score
                bestAction = action

        return bestAction


def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: Evaluates the state by encouraging food collection, avoiding ghosts, chasing scared ghosts, and penalizing inactivity.
    """
    "*** YOUR CODE HERE ***"
    score = currentGameState.getScore()
    pacPos = currentGameState.getPacmanPosition()
    foodList = currentGameState.getFood().asList()
    capsules = currentGameState.getCapsules()
    ghostStates = currentGameState.getGhostStates()
    scaredTimes = [ghost.scaredTimer for ghost in ghostStates]

    # Food
    if foodList:
        foodDistances = [manhattanDistance(pacPos, food) for food in foodList]
        minFoodDist = min(foodDistances)
        score += 15.0 / (minFoodDist + 1)  # Encourage approaching the nearest food
        if pacPos in foodList:
            score += 25  # Bonus for actually eating a piece of food
    else:
        score += 500  # Big reward if all food has been eaten


    if capsules:
        capDistances = [manhattanDistance(pacPos, cap) for cap in capsules]
        minCapDist = min(capDistances)
        score += 8.0 / (minCapDist + 1)
        if pacPos in capsules:
            score += 30

    # Ghost
    for i, ghost in enumerate(ghostStates):
        ghostPos = ghost.getPosition()
        ghostDist = manhattanDistance(pacPos, ghostPos)
        if scaredTimes[i] > 0:
            # Ghost is scared, and encourage approaching to eat it
            score += 10.0 / (ghostDist + 1)
        else:
            # Ghost is dangerous, and avoid it
            if ghostDist < 2:
                score -= 80
            elif ghostDist < 5:
                score -= 6.0 / (ghostDist + 1)

    # Encourage reducing remaining food
    score += 100.0 / (len(foodList) + 1)

    # Bonus for longer scared time
    score += 10 * sum(scaredTimes)
    
    return score


# Abbreviation
better = betterEvaluationFunction
