import nn

class PerceptronModel(object):
    def __init__(self, dimensions):
        """
        Initialize a new Perceptron instance.

        A perceptron classifies data points as either belonging to a particular
        class (+1) or not (-1). `dimensions` is the dimensionality of the data.
        For example, dimensions=2 would mean that the perceptron must classify
        2D points.
        """
        self.w = nn.Parameter(1, dimensions)

    def get_weights(self):
        """
        Return a Parameter instance with the current weights of the perceptron.
        """
        return self.w

    def run(self, x):
        """
        Calculates the score assigned by the perceptron to a data point x.

        Inputs:
            x: a node with shape (1 x dimensions)
        Returns: a node containing a single number (the score)
        """
        "*** YOUR CODE HERE ***"
        return nn.DotProduct(x, self.w)

    def get_prediction(self, x):
        """
        Calculates the predicted class for a single data point `x`.

        Returns: 1 or -1
        """
        "*** YOUR CODE HERE ***"
        score_node = self.run(x)
        score = nn.as_scalar(score_node)
        if score >= 0:
            return 1
        else:
            return -1

    def train(self, dataset):
        """
        Train the perceptron until convergence.
        """
        "*** YOUR CODE HERE ***"
        while True:
            made_update = False

            # Iterate through dataset one example at a time
            for x, y in dataset.iterate_once(1):
                prediction = self.get_prediction(x)
                label = nn.as_scalar(y)

                if prediction != label:
                    # Compute direction = label * x
                    direction = nn.Constant(label * x.data)
                    self.w.update(direction, 1.0)
                    made_update = True

            if made_update == False:
                break

class RegressionModel(object):
    """
    A neural network model for approximating a function that maps from real
    numbers to real numbers. The network should be sufficiently large to be able
    to approximate sin(x) on the interval [-2pi, 2pi] to reasonable precision.
    """
    def __init__(self):
        # Initialize your model parameters here
        "*** YOUR CODE HERE ***"
        hidden_size = 512

        # First layer
        self.W1 = nn.Parameter(1, hidden_size)
        self.b1 = nn.Parameter(1, hidden_size)

        # Second layer
        self.W2 = nn.Parameter(hidden_size, 1)
        self.b2 = nn.Parameter(1, 1)

    def run(self, x):
        """
        Runs the model for a batch of examples.

        Inputs:
            x: a node with shape (batch_size x 1)
        Returns:
            A node with shape (batch_size x 1) containing predicted y-values
        """
        "*** YOUR CODE HERE ***"
        # First linear transformation
        first_linear = nn.Linear(x, self.W1)
        first_bias = nn.AddBias(first_linear, self.b1)

        # Apply ReLU activation
        first_relu = nn.ReLU(first_bias)

        # Second linear transformation
        second_linear = nn.Linear(first_relu, self.W2)
        output = nn.AddBias(second_linear, self.b2)

        return output

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        Inputs:
            x: a node with shape (batch_size x 1)
            y: a node with shape (batch_size x 1), containing the true y-values
                to be used for training
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        predictions = self.run(x)
        loss = nn.SquareLoss(predictions, y)
        return loss

    def train(self, dataset):
        """
        Trains the model.
        """
        "*** YOUR CODE HERE ***"
        batch_size = 200
        learning_rate = 0.05

        # Loop until the model reaches a sufficiently low loss
        while True:
            for x, y in dataset.iterate_once(batch_size):
                # Compute the loss
                loss = self.get_loss(x, y)

                # Stop training if loss is low enough
                if nn.as_scalar(loss) < 0.02:
                    return

                # Compute gradients with respect to parameters
                gradients = nn.gradients(loss, [self.W1, self.b1, self.W2, self.b2])

                # Update parameters using gradient descent
                self.W1.update(gradients[0], -learning_rate)
                self.b1.update(gradients[1], -learning_rate)
                self.W2.update(gradients[2], -learning_rate)
                self.b2.update(gradients[3], -learning_rate)

class DigitClassificationModel(object):
    """
    A model for handwritten digit classification using the MNIST dataset.

    Each handwritten digit is a 28x28 pixel grayscale image, which is flattened
    into a 784-dimensional vector for the purposes of this model. Each entry in
    the vector is a floating point number between 0 and 1.

    The goal is to sort each digit into one of 10 classes (number 0 through 9).

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # Initialize your model parameters here
        "*** YOUR CODE HERE ***"
        hidden_size = 200

        # Input is 784, output is 10
        self.W1 = nn.Parameter(784, hidden_size)
        self.b1 = nn.Parameter(1, hidden_size)

        self.W2 = nn.Parameter(hidden_size, 10)
        self.b2 = nn.Parameter(1, 10)

    def run(self, x):
        """
        Runs the model for a batch of examples.

        Your model should predict a node with shape (batch_size x 10),
        containing scores. Higher scores correspond to greater probability of
        the image belonging to a particular class.

        Inputs:
            x: a node with shape (batch_size x 784)
        Output:
            A node with shape (batch_size x 10) containing predicted scores
                (also called logits)
        """
        "*** YOUR CODE HERE ***"
        # First linear layer
        layer1 = nn.Linear(x, self.W1)
        layer1 = nn.AddBias(layer1, self.b1)
        layer1 = nn.ReLU(layer1)  # Apply ReLU activation

        # Second linear layer
        output = nn.Linear(layer1, self.W2)
        output = nn.AddBias(output, self.b2)

        return output

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 10). Each row is a one-hot vector encoding the correct
        digit class (0-9).

        Inputs:
            x: a node with shape (batch_size x 784)
            y: a node with shape (batch_size x 10)
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        predicted_scores = self.run(x)
        return nn.SoftmaxLoss(predicted_scores, y)

    def train(self, dataset):
        """
        Trains the model.
        """
        "*** YOUR CODE HERE ***"
        batch_size = 100
        learning_rate = 0.5

        while True:
            for x, y in dataset.iterate_once(batch_size):
                # Compute loss
                loss = self.get_loss(x, y)

                # Compute gradients for all parameters
                grads = nn.gradients(loss, [self.W1, self.b1, self.W2, self.b2])

                # Update parameters using gradient descent
                self.W1.update(grads[0], -learning_rate)
                self.b1.update(grads[1], -learning_rate)
                self.W2.update(grads[2], -learning_rate)
                self.b2.update(grads[3], -learning_rate)

            # Check validation accuracy
            acc = dataset.get_validation_accuracy()
            if acc >= 0.98:
                return

class LanguageIDModel(object):
    """
    A model for language identification at a single-word granularity.

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # Our dataset contains words from five different languages, and the
        # combined alphabets of the five languages contain a total of 47 unique
        # characters.
        # You can refer to self.num_chars or len(self.languages) in your code
        self.num_chars = 47
        self.languages = ["English", "Spanish", "Finnish", "Dutch", "Polish"]

        # Initialize your model parameters here
        "*** YOUR CODE HERE ***"
        self.hidden_size = 200

        self.Wx = nn.Parameter(self.num_chars, self.hidden_size)
        self.bx = nn.Parameter(1, self.hidden_size)

        self.Wh = nn.Parameter(self.hidden_size, self.hidden_size)
        self.bh = nn.Parameter(1, self.hidden_size)

        self.W_mid = nn.Parameter(self.hidden_size, self.hidden_size)
        self.b_mid = nn.Parameter(1, self.hidden_size)

        self.W_out = nn.Parameter(self.hidden_size, len(self.languages))
        self.b_out = nn.Parameter(1, len(self.languages))

    def run(self, xs):
        """
        Runs the model for a batch of examples.

        Although words have different lengths, our data processing guarantees
        that within a single batch, all words will be of the same length (L).

        Here `xs` will be a list of length L. Each element of `xs` will be a
        node with shape (batch_size x self.num_chars), where every row in the
        array is a one-hot vector encoding of a character. For example, if we
        have a batch of 8 three-letter words where the last word is "cat", then
        xs[1] will be a node that contains a 1 at position (7, 0). Here the
        index 7 reflects the fact that "cat" is the last word in the batch, and
        the index 0 reflects the fact that the letter "a" is the inital (0th)
        letter of our combined alphabet for this task.

        Your model should use a Recurrent Neural Network to summarize the list
        `xs` into a single node of shape (batch_size x hidden_size), for your
        choice of hidden_size. It should then calculate a node of shape
        (batch_size x 5) containing scores, where higher scores correspond to
        greater probability of the word originating from a particular language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
        Returns:
            A node with shape (batch_size x 5) containing predicted scores
                (also called logits)
        """
        "*** YOUR CODE HERE ***"
        # First character
        h = nn.Linear(xs[0], self.Wx)
        h = nn.AddBias(h, self.bx)
        h = nn.ReLU(h)

        # Loop through the rest of the characters
        for i in range(1, len(xs)):
            x_proj = nn.Linear(xs[i], self.Wx)

            h_proj = nn.Linear(h, self.Wh)

            # Add the two, then apply bias and ReLU
            h = nn.Add(x_proj, h_proj)
            h = nn.AddBias(h, self.bh)
            h = nn.ReLU(h)
        
        mid = nn.Linear(h, self.W_mid)
        mid = nn.AddBias(mid, self.b_mid)
        mid = nn.ReLU(mid)

        # Pass it through a linear layer to get scores for each language
        logits = nn.Linear(mid, self.W_out)
        logits = nn.AddBias(logits, self.b_out)

        return logits

    def get_loss(self, xs, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 5). Each row is a one-hot vector encoding the correct
        language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
            y: a node with shape (batch_size x 5)
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        logits = self.run(xs)
        return nn.SoftmaxLoss(logits, y)

    def train(self, dataset):
        """
        Trains the model.
        """
        "*** YOUR CODE HERE ***"
        batch_size = 100
        learning_rate = 0.2

        patience = 3
        best_acc = 0
        count = 0
        
        for epoch in range(100):
            for xs, y in dataset.iterate_once(batch_size):
                loss = self.get_loss(xs, y)

                # Compute gradients
                grads = nn.gradients(loss, [
                    self.Wx, self.bx,
                    self.Wh, self.bh,
                    self.W_mid, self.b_mid,
                    self.W_out, self.b_out
                ])

                # Update all parameters
                self.Wx.update(grads[0], -learning_rate)
                self.bx.update(grads[1], -learning_rate)
                self.Wh.update(grads[2], -learning_rate)
                self.bh.update(grads[3], -learning_rate)
                self.W_mid.update(grads[4], -learning_rate)
                self.b_mid.update(grads[5], -learning_rate)
                self.W_out.update(grads[6], -learning_rate)
                self.b_out.update(grads[7], -learning_rate)

            # Get the current validation accuracy
            acc = dataset.get_validation_accuracy()

            if acc > best_acc:
                best_acc = acc
                count = 0
            else:
                count += 1

            if best_acc >= 0.82 and count >= patience:
                break